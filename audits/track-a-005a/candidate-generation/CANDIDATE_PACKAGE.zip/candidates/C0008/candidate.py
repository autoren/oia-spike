import numpy as np
import copy
from typing import Dict, Any, Tuple

RUNNING = "RUNNING"
LEVEL_COMPLETED = "LEVEL_COMPLETED"
GAME_OVER = "GAME_OVER"

def initial_state(initial_frame: np.ndarray) -> Dict[str, Any]:
    return {
        "frame": copy.deepcopy(initial_frame),
        "step_count": 0
    }

def render(state: Dict[str, Any]) -> np.ndarray:
    return copy.deepcopy(state["frame"])

def step(state: Dict[str, Any], action: str) -> Tuple[Dict[str, Any], str]:
    if action not in ["ACTION6", "ACTION7"]:
        raise ValueError("Invalid action")
    
    new_state = copy.deepcopy(state)
    new_state["step_count"] += 1
    frame = new_state["frame"]
    
    if action == "ACTION6":
        # Hypothesis: ACTION6 triggers a deterministic vertical shift of the 
        # upper-right cluster (rows 11-19, cols 50-58) by 1 pixel downward.
        # This challenges the interpretation that the cluster is static or 
        # controlled by a different axis.
        if new_state["step_count"] <= 3:
            # Shift the specific region down by 1
            # Source: rows 11-18, cols 50-58
            # Dest: rows 12-19, cols 50-58
            # We must clear the bottom row of the destination first to avoid smearing
            # and then copy the source above it.
            
            # Define the bounding box of the object
            r_start, r_end = 11, 19
            c_start, c_end = 50, 59
            
            # Clear the bottom-most row of the object's current footprint
            # to prepare for the shift down
            frame[r_end-1, c_start:c_end] = 5  # Background color is 5
            
            # Shift the content down
            # Copy rows 11-18 to 12-19
            frame[r_start+1:r_end, c_start:c_end] = frame[r_start:r_end-1, c_start:c_end].copy()
            
            # The top row (11) is now empty in the object's logical space, 
            # but since we shifted down, the top row of the *new* position 
            # (row 12) holds what was in row 11.
            # The original top row (11) should revert to background if it was part of the object.
            # However, looking at the raster, row 11 is the top of the object.
            # If we shift down, row 11 becomes background.
            frame[r_start, c_start:c_end] = 5

    elif action == "ACTION7":
        # Hypothesis: ACTION7 triggers a horizontal shift of the 
        # lower-left cluster (rows 48-52, cols 3-7) by 1 pixel to the right.
        if new_state["step_count"] <= 3:
            r_start, r_end = 48, 53
            c_start, c_end = 3, 8
            
            # Clear the right-most column
            frame[r_start:r_end, c_end-1] = 5
            
            # Shift right
            frame[r_start:r_end, c_start+1:c_end] = frame[r_start:r_end, c_start:c_end-1].copy()
            
            # Revert left-most column to background
            frame[r_start:r_end, c_start] = 5

    return new_state, RUNNING
