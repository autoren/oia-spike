# Release Notes — OIA-1 v0.2.0

**Date:** 2026-08-21

## Research standard

- Added the Track A / Track B distinction.
- Authorized opened public-substrate instrument validation under numbered freezes.
- Kept sealed necessary-revision, evaluator-private identification, and decision-superiority claims behind the stricter Track B gate.

## Integrity fixes

- Added adaptive `witness` status for sound cap-limited policies whose depth is not globally certified.
- Reserved `solved` for complete enumeration and exact minimum depth.
- Prohibited cap-limited impossibility in the API and verifier.
- Added `enumeration_complete`, `optimality_certified`, and `depth_claim` fields.
- Separated deterministic structural scaling evidence from console-only timing.
- Fixed stable-partition block-ID relabeling that caused nontermination on the external codec family.

## Track A external slice

- Added a substrate-specific opaque finite-horizon adapter for five CPython incremental codecs.
- Independently replayed 90 states and 630 transitions.
- Preserved audit 000 scaling noncompletion and audit 001 pre-outcome instrument failure.
- Completed audit 002 with exact adaptive identity depth 3, decision depth 1, exact preset-identity impossibility, five passing direct black-box paths, and prospective `outside_model` detection on frozen target `cp437` at step 1.

## Validation

- 22 deterministic tests pass.
- 1,927 randomized differential checks pass.
- Consecutive scaling runs produce identical structural JSON SHA-256.
- Audit freeze, pre-outcome, closure, and final manifests verify.

## Claim boundary

This release validates a bounded instrument. It does not establish autonomous ontology formation, necessary ontology revision, sealed identification, semantic grounding, or decision superiority.
