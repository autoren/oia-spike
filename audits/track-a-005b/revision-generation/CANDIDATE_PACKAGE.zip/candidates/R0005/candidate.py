import numpy as np
from typing import Dict, Any, Tuple

RUNNING = "RUNNING"
LEVEL_COMPLETED = "LEVEL_COMPLETED"
GAME_OVER = "GAME_OVER"

def initial_state(initial_frame: np.ndarray) -> Dict[str, Any]:
    return {
        "frame": np.array(initial_frame, dtype=np.int32),
        "step_count": 0,
        "action_history": []
    }

def render(state: Dict[str, Any]) -> np.ndarray:
    return state["frame"].copy()

def step(state: Dict[str, Any], action: str) -> Tuple[Dict[str, Any], str]:
    if action not in ["ACTION6", "ACTION7"]:
        raise ValueError("Invalid action")
        
    new_state = copy.deepcopy(state)
    new_state["step_count"] += 1
    new_state["action_history"].append(action)
    
    frame = new_state["frame"]
    
    if action == "ACTION6":
        if new_state["step_count"] == 1:
            frame[63, 63] = 5
            frame[63, 62] = 5
        else:
            frame[63, 63] = 5
            frame[63, 62] = 5
    else:
        if new_state["step_count"] == 1:
            frame[63, 63] = 0
            frame[63, 62] = 0
        else:
            frame[63, 63] = 0
            frame[63, 62] = 0

    return new_state, RUNNING
