# CPython Codec Track A Slice

This directory contains the substrate-specific OIA-1 Track A adapter and two numbered diagnostic audits. It is not a general ontology compiler.

## Files

- `codec_adapter.py` — finite-horizon opaque adapter for CPython incremental decoders.
- `validate_adapter.py` — independent fresh-decoder trace replay used during freezing.
- `prepare_audit.py` — deterministic audit 002 freeze script; refuses to overwrite an audit after a prospective outcome exists.
- `run_opened_audit.py` — computes and verifies the frozen OIA report without executing the target.
- `execute_prospective_outcome.py` — the one-time opened target runner used for audit 002.
- `audit_001/` — frozen diagnostic attempt closed before outcome after an instrument nontermination defect.
- `audit_002/` — corrected freeze, pre-outcome selection, black-box replay, prospective outcome, and complete manifests.

## Audit lineage

### Audit 000

All 256 byte actions plus `finish`, horizon 4. Complete reachable-state/edge replay did not complete within the 120-second engineering cap. No identifiability result was accepted.

### Audit 001

Seven-action diagnostic alphabet. The audit froze successfully, but OIA did not complete before outcome because stable partition blocks were repeatedly renumbered. The target was never executed. The original freeze and closure are both checksummed.

### Audit 002

Same public candidate family and diagnostic boundary, newly frozen after the convergence fix and instrument source-hash freeze. It completed and then executed the one predeclared `cp437` target.

## Revalidate the adapter

```bash
PYTHONPATH=src:external/cpython_codecs python - <<'PY'
import json
from pathlib import Path
from codec_adapter import CANDIDATE_CODECS, HORIZON
from validate_adapter import validate_family
_, result = validate_family(CANDIDATE_CODECS, horizon=HORIZON)
frozen = json.loads(Path(
    "external/cpython_codecs/audit_002/adapter_trace_validation.json"
).read_text())
assert result == frozen
print(result["total_states_checked"], result["total_edges_checked"])
PY
```

## Verify manifests

```bash
(cd external/cpython_codecs/audit_001 && sha256sum -c FREEZE_SHA256SUMS)
(cd external/cpython_codecs/audit_001 && sha256sum -c AUDIT_CLOSURE_SHA256SUMS)
(cd external/cpython_codecs/audit_002 && sha256sum -c FREEZE_SHA256SUMS)
(cd external/cpython_codecs/audit_002 && sha256sum -c PRE_OUTCOME_SHA256SUMS)
(cd external/cpython_codecs/audit_002 && sha256sum -c FINAL_SHA256SUMS)
```

Audit 002’s prospective outcome is already opened. Re-executing it is replication, not a new prospective test.
