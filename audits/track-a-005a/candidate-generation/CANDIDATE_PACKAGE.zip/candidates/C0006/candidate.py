import numpy as np
import copy
from typing import Dict, Any, Tuple

RUNNING = "RUNNING"
LEVEL_COMPLETED = "LEVEL_COMPLETED"
GAME_OVER = "GAME_OVER"

def initial_state(initial_frame: np.ndarray) -> Dict[str, Any]:
    return {
        "frame": copy.deepcopy(initial_frame),
        "mode": "IDLE",
        "step_count": 0
    }

def step(state: Dict[str, Any], action: str) -> Tuple[Dict[str, Any], str]:
    if action not in ["ACTION6", "ACTION7"]:
        raise ValueError("Invalid action")
    
    new_state = copy.deepcopy(state)
    new_state["step_count"] += 1
    new_frame = new_state["frame"].copy()
    
    if action == "ACTION6":
        # Toggle the top-right white block (FFF) to black (000)
        # Located at rows 4-6, cols 44-46
        new_frame[4:7, 44:47] = 0
        new_state["mode"] = "TOGGLED"
    else:
        # ACTION7: Toggle the bottom-left white block (FFF) to black (000)
        # Located at rows 52-54, cols 3-5
        new_frame[52:55, 3:6] = 0
        new_state["mode"] = "TOGGLED"
        
    new_state["frame"] = new_frame
    return new_state, RUNNING

def render(state: Dict[str, Any]) -> np.ndarray:
    return state["frame"].copy()
